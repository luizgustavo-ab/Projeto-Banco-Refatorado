#ifndef MENUS_H
#define MENUS_H

void menuprincipal();
void menufuncionario();
void menuaberturadeconta();
void menuexcluircontas();
void menuconsultardados();
void menualterardados();
void menurelatorios();
void verificarsenhaadm();
void verificarsenhafunc();
void submenuconsultarlimite();
void submenuextrato();
void submenusaque();
void submenudeposito();
void submenusaldo();
void menucliente();
void subsubmenualterarcliente();
void submenuconsultarcontas();
void submenualterarcontas();
void subsubmenualterarcontacp();
void subsubmenualterarcontacc();



#endif
