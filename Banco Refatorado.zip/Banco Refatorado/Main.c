#include "menus.h"
#include "menus.c"
#include "funcoes.h"
#include "funcoes.c"



int main() {
    menuprincipal();
    return 0;
}
